import WSChannel from './WSChannel';
export { WSChannel as ViewerChannel };
